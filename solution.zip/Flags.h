// Comment to test individual method
#define ALL 1

// Uncomment to test individual method
//#define CONSTRUCTOR 1
//#define DESTRUCTOR 1
//#define GETFIRST 1
//#define GETLAST 1
//#define FIND 1
//#define FINDNODE 1
//#define INSERT 1
//#define REMOVE 1
//#define ISEMPTY 1
//#define MAKEEMPTY 1
//#define COPY_CONSTRUCTOR 1
//#define ASSIGN 1
